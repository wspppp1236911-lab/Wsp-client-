package com.wspclient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleRegistry {
    private static final List<Module> MODULES = new ArrayList<>();
    private ModuleRegistry() {}

    public static void add(String category, String... names) {
        for (String name : names) MODULES.add(new Module(name, category, "Toggleable module"));
    }
    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }

    public static void init() {
        add("Combat", "Aim Assist", "Auto Clicker", "Trigger Bot", "Reach Display", "CPS Counter", "Hitbox Display", "Target HUD", "Combo Counter", "Attack Indicator", "Totem Counter", "Armor HUD", "Crosshair Editor", "Swing Animation", "Hit Sounds", "Damage Numbers");
        add("Render", "Chest ESP", "Player ESP", "Mob ESP", "Item ESP", "Storage ESP", "Tracers", "Name Tags", "Health Bars", "Entity Counter", "Fullbright", "Xray", "Waypoints", "Breadcrumbs", "Block Outline", "Cave Finder");
        add("Movement", "Fly (private worlds)", "Boat Fly (private worlds)", "Sprint", "Auto Sprint", "Step", "Safe Walk", "Spider (private worlds)", "Jesus (private worlds)", "No Slow", "Elytra HUD", "Speed Display", "Jump Boost", "Parkour", "Auto Walk", "Freecam");
        add("World", "Coordinates", "Biome Display", "Time Display", "Weather Display", "Seed Display", "Block Counter", "Durability Viewer", "Potion Timer", "Inventory Viewer", "Shulker Preview", "Chest Preview", "Container Search", "Map Preview", "Sign Search", "Structure Markers");
        add("Player", "Inventory HUD", "Armor HUD", "Potion HUD", "Totem HUD", "Keystrokes", "CPS Display", "Ping Display", "FPS Display", "Clock", "Compass");
        add("Utility", "Auto Tool", "Auto Eat", "Auto Respawn", "Auto Fish", "Auto Reconnect", "Inventory Sorter", "Item Counter", "Chat Filter", "Chat Timestamps", "Message History", "Screenshot Manager", "Config Manager", "Friend System", "Enemy List", "Macro Manager");
        add("GUI", "ClickGUI", "Search Bar", "Module Categories", "Theme Editor", "Color Picker", "HUD Editor", "Custom Fonts", "Animations", "Profiles", "Keybind Editor");
        add("Extra", "Discord RPC", "Custom Main Menu", "Mod Manager", "Notification System", "Module Descriptions", "Command System", "Preset Configs", "Custom Cape", "Performance Monitor");
    }
}
