package com.wspclient;

public final class Module {
    public final String name;
    public final String category;
    public boolean enabled;
    public final String description;

    public Module(String name, String category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }
}
