package com.wspclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class WSPClient implements ClientModInitializer {
    public static KeyBinding clickGuiKey;

    @Override public void onInitializeClient() {
        ModuleRegistry.init();
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.wspclient.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (clickGuiKey.wasPressed()) client.setScreen(new WSPClickScreen());
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (net.minecraft.client.MinecraftClient.getInstance().player != null) {
                drawContext.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                    Text.literal("WSPCLIENT 1.0"), 6, 6, 0xFFFF8A35, true);
            }
        });
    }
}
