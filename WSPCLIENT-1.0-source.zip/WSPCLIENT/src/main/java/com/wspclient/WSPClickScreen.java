package com.wspclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class WSPClickScreen extends Screen {
    private int scroll;
    public WSPClickScreen() { super(Text.literal("WSPCLIENT")); }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int left = width / 2 - 150, top = 35;
        ctx.fill(left, top, left + 300, height - 30, 0xEE17131F);
        ctx.fill(left, top, left + 300, top + 28, 0xFF7A35C8);
        ctx.drawText(textRenderer, "WSPCLIENT 1.0  |  RIGHT SHIFT", left + 10, top + 10, 0xFFFFFFFF, true);
        var modules = ModuleRegistry.all();
        int y = top + 38;
        for (int i = scroll; i < Math.min(modules.size(), scroll + 24); i++) {
            Module module = modules.get(i);
            int color = module.enabled ? 0xFFFF9A45 : 0xFFB9B2C5;
            ctx.drawText(textRenderer, module.category + "  /  " + module.name + (module.enabled ? "  [ON]" : "  [OFF]"), left + 12, y, color, true);
            y += 12;
        }
        ctx.drawText(textRenderer, "Click a row to toggle  |  scroll to browse", left + 10, height - 43, 0xFFB9B2C5, true);
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int left = width / 2 - 150, top = 35;
            int row = (int) ((mouseY - (top + 38)) / 12) + scroll;
            if (mouseX >= left && mouseX <= left + 300 && row >= 0 && row < ModuleRegistry.all().size()) {
                ModuleRegistry.all().get(row).enabled = !ModuleRegistry.all().get(row).enabled;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(ModuleRegistry.all().size() - 1, scroll - (int) Math.signum(verticalAmount) * 3));
        return true;
    }
    @Override public boolean shouldPause() { return false; }
}
