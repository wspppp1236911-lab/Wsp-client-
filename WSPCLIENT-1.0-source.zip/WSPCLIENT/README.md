# WSPCLIENT 1.0 (starter build)

Fabric client project for Minecraft 1.21.11 / Java 21.

## Build

Install JDK 21 and Gradle 8.14 or newer, then run:

```sh
gradle build
```

The output JAR will be in `build/libs/`.

## Current implementation

- Right Shift opens the WSPCLIENT ClickGUI.
- The GUI lists the planned module catalogue and lets you toggle module states.
- A small WSPCLIENT HUD label is rendered in-game.

## Important

The catalogue is a roadmap, not a claim that every listed module is implemented. Modules that alter movement or game state need their own implementation and testing. This starter does not include anti-cheat bypass code.
